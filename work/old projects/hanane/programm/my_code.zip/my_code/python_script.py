import sys
import subprocess
import os.path
import csv
import numpy as np
import matplotlib.pyplot as plt

def set_parameters(n,p,vpair= -512.95 ,deformation="0"):
    text =""
    with open("hfbtho_NAMELIST_original.dat") as file:
        text = file.read()
#        if n % 2 == 1:
            #n-=1
            #text=text.replace("neutron_blocking = 0, 0, 0, 0, 0", "neutron_blocking = 1, 0, 0, 0, 0")
        text = text.replace("proton_number = 100", "proton_number = "+ str(p)).replace("neutron_number = 100", "neutron_number = " + str(n)).replace("-2000.0",str(vpair)).replace("-555", deformation)
    input_file = open("hfbtho_NAMELIST.dat","w")
    input_file.write(text)
    input_file.close()

def run_HFBTHO(n,p):
    #subprocess.call(["rm", "hfbtho_output.hel"])
    file = open("./out.txt","w")
    subprocess.call(["./hfbtho_main", "<" , "/dev/null" , ">&" , "[output_file]"],stdout=file, shell = False)
    subprocess.call(["cp", "thoout.dat" , "./results/output_"+str(p)+"_"+str(n)])

def read_values(path):
    with open(path, "r") as file:
        for line in file:
            if ("tEnergy: ehfb (qp)..." in line):
                BE = -1 * float(line.split()[-1])
            if ("pairing energy" in line):
                PE =-1* float(line.split()[-1])
            if ("rms-radius" in line):
                Rn = float(line.split()[2])
                Rp = float(line.split()[3])
    return BE, PE, Rn ,Rp

def calculate_values(n,p,vpair= -512.95 ,deformation="0"):
    path = "./results/output_"+str(p)+"_"+str(n)
    if( os.path.isfile(path)):
        return read_values(path)
    else:
        set_parameters(n,p,vpair,deformation)
        run_HFBTHO(n,p)
        return read_values(path)


def calculate_Sn(n,p, neutron_number):
    return calculate_values(n,p)[0]-calculate_values(n-neutron_number,p)[0]
    

# read data from csv file
file = open("data.csv")
csvreader  = csv.reader(file)
header = next(csvreader)
exp_energys = {}
frdm_energys = {}
relative_energys = {}

for line in csvreader:
    n = int(line[0])
    if (not line[3] == ""):
        exp_energys[n] = float(line[3])
    if (not line[1] == ""):
        frdm_energys[n] = float(line[1])
    if (not line[2] == ""):
        relative_energys[n] = float(line[2])

file.close()

p= 114

calculated_energys = {}
calculated_pairing_energy = {}
calculated_Rn = {}
calculated_Rp = {}
calculate_Sn1 = {}
calculate_Sn2 = {}

#deformation_state =  ["0.3","0.2","0.1","0","-0.1","-0.2" ,"-0.3" ]
deformation_state = "0"
for n in range(155  , 261):
    best_vals = None
    exp_energy = 0

    # find the best vpair only in the first run for n = 170
    step = 0.05
    vpair = -512.95
#    for vpair in np.arange(-513,-512.86,step):
        #print("the vpair is ", vpair, "step",step)
        # find the best state
        #for state in deformation_state:
    vals_for_state= calculate_values(n, p, vpair, deformation_state)
    energy = vals_for_state[0]
        #if (best_vals is None):
            #best_vals= vals_for_state
        #elif (abs(best_vals[0]- exp_energy) > abs(vals_for_state[0]- exp_energy) ):
            #best_vals = vals_for_state
    calculated_energys[n]=  energy
    calculated_pairing_energy[n] = vals_for_state[1]
    calculated_Rn[n] =  vals_for_state[2]
    calculated_Rp[n]=  vals_for_state[3]
    calculate_Sn1[n] = calculate_Sn(n,p,1)
    calculate_Sn2[n] = calculate_Sn(n,p,2)



file = open("calculated_values.csv","w")
file.write("N ,FRDM,relativistic continuum Hartree-Bogoliubov theory ,exp_energy,calculated_enery,P_e,R_n,R_p,S_n1,S_n2 \n")
for n in calculated_energys.keys():
    line =str(n)+","+str(frdm_energys.get(n))+","+str(relative_energys.get(n))+","+ str(exp_energys.get(n))+","+ str(calculated_energys[n])+","+str(calculated_pairing_energy[n]) + ","+ str(calculated_Rn[n]) + "," + str(calculated_Rp[n]) + ","+str(calculate_Sn1[n])+","+ str(calculate_Sn2[n])+ "\n"
    file.write(line)

file.close()

x= list(frdm_energys.keys())
x = np.array(x)
y = list(frdm_energys.values())
y = np.array(y) / (x+p)
plt.plot(x,y)

frdm_energys = calculated_energys
x= list(frdm_energys.keys())
x = np.array(x)
y = list(frdm_energys.values())
y = np.array(y) / (x+p)
plt.plot(x,y)




frdm_energys = relative_energys
x= list(frdm_energys.keys())
x = np.array(x)
y = list(frdm_energys.values())
y = np.array(y) / (x+p)
plt.plot(x,y)

frdm_energys = exp_energys
x= list(frdm_energys.keys())
x = np.array(x)
y = list(frdm_energys.values())
y = np.array(y) / (x+p)
plt.plot(x,y)


plt.show()

